import React, { useState } from 'react';
import { Select } from '../../components/Select/Select';
import { NavigationMenu } from '../../components/NavigationMenu/NavigationMenu';
import {
  HeaderContainer,
  HeaderWrap,
  HeaderNavigationContainer,
  HeaderDropDownContainer,
  GlobalStyle,
  NavigationMobile
} from './HeaderElements';

// array of objects for drop down information
const dropDownData = [
  {
    id: 0,
    title: "student@school.org",
  },
  {
    id: 1,
    title: "Settings",
  },
  {
    id: 2,
    title: "Sign Out",
  },
];

// array of objects for navigation menu
const navigationData = [
  {
    id: 0,
    title: "Classes",
  },
  {
    id: 1,
    title: "Lessons",
  },
  {
    id: 2,
    title: "Libraries",
  },
];

const Header: React.FC = () => {

  const [isOpenMobileMenu, setIsOpenMobileMenu] = useState(false);

  return (
    <HeaderContainer>
      <GlobalStyle />
      <HeaderWrap>
        <HeaderNavigationContainer>
          <NavigationMobile className="navbar-mobile"
            onClick={() => setIsOpenMobileMenu(!isOpenMobileMenu)}
          >
            {!isOpenMobileMenu && 
            <i className="fa fa-bars"></i>}
            {isOpenMobileMenu && 
            <i className="fa fa-close"></i>}
            
            <a href="#" className="mobile-btn">Menu</a>
          </NavigationMobile>
          <NavigationMenu options={navigationData} isSelected={0} selected={false} isMobileOpen={isOpenMobileMenu}/>
        </HeaderNavigationContainer>
        <HeaderDropDownContainer>
          <Select options={dropDownData}/>
        </HeaderDropDownContainer>
      </HeaderWrap>
    </HeaderContainer>
  );
};

export default Header;
