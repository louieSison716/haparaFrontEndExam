export const CHANGE_FILTER = "advanced";
export const CLOSE_FILTER = "close filter";