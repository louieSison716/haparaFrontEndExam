export const AVATAR = 'avatar-placeholder.gif';
export const LOADING = 'Loading';