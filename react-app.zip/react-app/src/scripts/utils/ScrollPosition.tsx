export const scrollPosition = (position: any) => {
  document.body.scrollTop = position;
  document.documentElement.scrollTop = position;
}