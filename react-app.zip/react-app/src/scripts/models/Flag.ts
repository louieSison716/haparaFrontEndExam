export interface Flag {
	readonly name: string;
}