import React, { useState } from "react";
import {SelectOpener, OptionList, OptionListTitle} from '../../modules/header/HeaderElements';

interface Option {
  id: number;  
  title: string;
}

interface ChildComponentProps  {
    options?: Option[];
    isSelectOpen?: boolean;
}

export const Select: React.FC<ChildComponentProps>  = (props) => {
    
    const [isOpen, setIsOpen] = useState(false);
    const [selectedOption, setSelectedOption] = useState<string | null>(null);

    return (
      <SelectOpener onClick={() => setIsOpen(!isOpen)}>
        <OptionListTitle>
          {selectedOption || "teacher@school.org"}
          {!isOpen && <i className="fa fa-angle-down" aria-hidden="true"></i>}
          {isOpen && <i className="fa fa-angle-up" aria-hidden="true"></i>}
          
        </OptionListTitle>
        {isOpen && <OptionList>
        {props.options.map((option) => <li key={option.id} onClick={()=> setSelectedOption(option.title)}>
          <span>{option.title}</span></li>)}
        </OptionList>}
      </SelectOpener>
    );
};